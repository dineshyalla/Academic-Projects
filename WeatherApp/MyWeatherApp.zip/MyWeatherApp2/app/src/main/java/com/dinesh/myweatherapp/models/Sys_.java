package com.dinesh.myweatherapp.models;

/**
 * Created by sandy on 25-04-2017.
 */
public class Sys_ {
    private String pod;

    public String getPod() {
        return pod;
    }

    public void setPod(String pod) {
        this.pod = pod;
    }
}
