package com.dinesh.myweatherapp.models;

import java.util.ArrayList;

/**
 * Created by sandy on 25-04-2017.
 */

public class WeatherAPIResult {
    private City city;
    private String message;
    private String cod;
    private Integer count;
    private ArrayList<Area> list = new ArrayList<Area>();


    public City getCity() {
        return city;
    }

    public void setCity(City city) {
        this.city = city;
    }

    public String getCod() {
        return cod;
    }

    public void setCod(String cod) {
        this.cod = cod;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public Integer getCount() {
        return count;
    }

    public void setCount(Integer cnt) {
        this.count = cnt;
    }

    public ArrayList<Area> getList() {
        return list;
    }

    public void setList(ArrayList<Area> list) {
        this.list = list;
    }
}
