package com.dinesh.myweatherapp;

import android.Manifest;
import android.content.pm.PackageManager;
import android.graphics.Typeface;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.View;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.dinesh.myweatherapp.Interface.WeatherApiInterface;
import com.dinesh.myweatherapp.adapter.WeatherAdapter;
import com.dinesh.myweatherapp.models.WeatherAPIResult;
import com.dinesh.myweatherapp.rest.RestClient;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class WeatherDetailsActivity extends AppCompatActivity {

    private static final String TAG = "SPLASH";
    private static final int PERMISSION_REQUEST_CODE = 1;
    private RecyclerView mRecyclerView;
    private RecyclerView.Adapter mAdapter;
    private RecyclerView.LayoutManager mLayoutManager;

    private Typeface weatherFont;
    private String place_location="", place_country="";
    private ProgressBar spinner;

    TextView weather_report,place,weather_icon,country,icon_text;
    List myList ;
    String API_KEY="57ae88d2618b7be820f2196c4ea99a91"; //insert api key here
    private final static String PATH_TO_WEATHER_FONT = "fonts/weather.ttf";
    private ListView lv;
    GPSTracker gpsTracker;
    Toolbar toolbar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_weather_details);
        toolbar = (Toolbar) findViewById(R.id.toolbar);

        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
            }
        });

        spinner = (ProgressBar)findViewById(R.id.progressBar1);
        spinner.setVisibility(View.VISIBLE);
        weatherFont = Typeface.createFromAsset(getAssets(), PATH_TO_WEATHER_FONT);

        mRecyclerView = (RecyclerView) findViewById(R.id.recycler_id);

        mRecyclerView.setHasFixedSize(true);
        // use a linear layout manager
        mLayoutManager = new LinearLayoutManager(this);
        mRecyclerView.setLayoutManager(mLayoutManager);


        checkPermission();



    }

    public void getWeather(){

        if (gpsTracker.getIsGPSTrackingEnabled())
        {
            String stringLatitude = String.valueOf(gpsTracker.latitude);
            String stringLongitude = String.valueOf(gpsTracker.longitude);

            WeatherApiInterface service = RestClient.getClient();
            Call<WeatherAPIResult> call = service.getWeather(stringLatitude, stringLongitude, API_KEY);
            call.enqueue(new Callback<WeatherAPIResult>() {
                @Override
                public void onResponse(Call<WeatherAPIResult> call, Response<WeatherAPIResult> response) {
                    if(response.isSuccessful()){
                        WeatherAPIResult result = response.body();
                        place_location = result.getCity().getName();
                        place_country = result.getCity().getCountry();

                        toolbar.setTitle( place_location + "("+ place_country +")");
                        setSupportActionBar(toolbar);

                        Log.w("icon", result.getList().get(0).getWeather().get(0).getIcon());


                        String[]humidity = new String[10];
                        String[]rain_description=new String[10];
                        String[]icon=new String[10];
                        String[]time=new String[10];
                        ArrayList<Weather> weathers = new ArrayList<>();
                        for (int i=0; i<result.getList().size();i++){
                            if(i==9)
                                break;
                            humidity[i] = String.valueOf(result.getList().get(i).getMain().getHumidity());
                            rain_description[i] = String.valueOf(result.getList().get(i).getWeather().get(0).getDescription());
                            icon[i] = String.valueOf(result.getList().get(i).getWeather().get(0).getIcon());
                            time[i] = String.valueOf(result.getList().get(i).getDt());

                            Log.w("humidity",humidity[i]);
                            Log.w("rain_description",rain_description[i]);
                            Log.w("icon",icon[i]);
                            Log.w("time",time[i]);

                            weathers.add(new Weather(String.valueOf(result.getList().get(i).getWeather().get(0).getIcon()), String.valueOf(result.getList().get(i).getMain().getHumidity()), String.valueOf(result.getList().get(i).getWeather().get(0).getDescription()), String.valueOf(result.getList().get(i).getDt())));

                        }
                        mAdapter = new WeatherAdapter(weathers,weatherFont);
                        mRecyclerView.setAdapter(mAdapter);

                        spinner.setVisibility(View.GONE);

                        Gson gson = new GsonBuilder().setPrettyPrinting().create();
                        Log.d("MainActivity", gson.toJson(result).toString());
                    }else {
                        spinner.setVisibility(View.GONE);
                        Log.d("Failed", response.raw().toString());
                    }
                }

                @Override
                public void onFailure(Call<WeatherAPIResult> call, Throwable t) {
                    spinner.setVisibility(View.GONE);
                    Log.e("onFailure",  t.toString());
                }
            });

            String postalCode = gpsTracker.getPostalCode(this);

            String addressLine = gpsTracker.getAddressLine(this);
        }
        else
        {

            // can't get location
            // GPS or Network is not enabled
            // Ask user to enable GPS/network in settings
            gpsTracker.showSettingsAlert();
        }

    }

    private boolean checkPermission(){
        int result = ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION);
        if (result == PackageManager.PERMISSION_GRANTED){

            gpsTracker = new GPSTracker(this);
            getWeather();

        } else {

            ActivityCompat.requestPermissions(this,new String[]{Manifest.permission.ACCESS_FINE_LOCATION},PERMISSION_REQUEST_CODE);

        }
        return true;
    }


    @Override
    public void onRequestPermissionsResult(int requestCode, String permissions[], int[] grantResults) {
        switch (requestCode) {
            case PERMISSION_REQUEST_CODE:
                if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {

                    Snackbar.make( getWindow().getDecorView().getRootView(),"Permission Granted, Now you can access location data.",Snackbar.LENGTH_LONG).show();
                    checkPermission();

                } else {

                    Snackbar.make( getWindow().getDecorView().getRootView(),"Permission Denied, You cannot access location data.",Snackbar.LENGTH_LONG).show();
                    finish();

                }
                break;
        }
    }
    @Override
    protected void onRestart() {
        super.onRestart();
        Log.d("OnRestart", "Activity restarted");

    }
}
