package com.dinesh.myweatherapp.Interface;

import com.dinesh.myweatherapp.models.WeatherAPIResult;

import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Query;

/**
 * Created by sandy on 25-04-2017.
 */

public interface WeatherApiInterface {
    @GET("/data/2.5/forecast")
    Call<WeatherAPIResult> getWeather(@Query("lat") String lat, @Query("lon") String lon, @Query("APPID") String appID);
}
