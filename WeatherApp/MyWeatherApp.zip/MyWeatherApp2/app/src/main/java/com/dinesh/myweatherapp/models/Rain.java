package com.dinesh.myweatherapp.models;

/**
 * Created by sandy on 25-04-2017.
 */
public class Rain {
}
