package com.dinesh.myweatherapp.rest;

import com.dinesh.myweatherapp.Interface.WeatherApiInterface;

import okhttp3.OkHttpClient;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

/**
 * Created by sandy on 25-04-2017.
 */

public class RestClient {
    private static String baseUrl = "http://api.openweathermap.org";
    private static WeatherApiInterface weatherApiInterface;

    //Set up the REST client
    public static WeatherApiInterface getClient() {
        if (weatherApiInterface == null) {

            OkHttpClient okClient = new OkHttpClient();
            /*okClient.interceptors().add(new Interceptor() {
                @Override
                public Response intercept(Chain chain) throws IOException {
                    Response response = chain.proceed(chain.request());
                    return response;
                }
            });*/

            Retrofit client = new Retrofit.Builder()
                    .baseUrl(baseUrl)
                    .client(okClient)
                    .addConverterFactory(GsonConverterFactory.create())
                    .build();
            weatherApiInterface = client.create(WeatherApiInterface.class);
        }
        return weatherApiInterface ;
    }

}
