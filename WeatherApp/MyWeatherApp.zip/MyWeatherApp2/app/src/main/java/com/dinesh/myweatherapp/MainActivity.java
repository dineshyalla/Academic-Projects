package com.dinesh.myweatherapp;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;

import com.dinesh.myweatherapp.Interface.WeatherApiInterface;
import com.dinesh.myweatherapp.models.WeatherAPIResult;
import com.dinesh.myweatherapp.rest.RestClient;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        WeatherApiInterface service = RestClient.getClient();
        Call<WeatherAPIResult> call = service.getWeather("17.440080", "78.348917", "57ae88d2618b7be820f2196c4ea99a91");
        call.enqueue(new Callback<WeatherAPIResult>() {
            @Override
            public void onResponse(Call<WeatherAPIResult> call, Response<WeatherAPIResult> response) {
                if(response.isSuccessful()){
                    WeatherAPIResult result = response.body();
                    Gson gson = new GsonBuilder().setPrettyPrinting().create();
                    Log.d("MainActivity", gson.toJson(result).toString());
                }else {
                    Log.d("Failed", response.raw().toString());
                }
            }

            @Override
            public void onFailure(Call<WeatherAPIResult> call, Throwable t) {
                Log.e("onFailure",  t.toString());
            }
        });
    }
}
